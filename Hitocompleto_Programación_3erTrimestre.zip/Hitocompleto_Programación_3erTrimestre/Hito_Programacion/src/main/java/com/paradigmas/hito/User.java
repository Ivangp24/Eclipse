package com.paradigmas.hito;

public class User {
    private String username;
    private String workoutPlan;
    private double weight;
    private int events;

    public User(String username, String workoutPlan, double weight, int events) {
        this.username = username;
        this.workoutPlan = workoutPlan;
        this.weight = weight;
        this.events = events;
    }

    // Getters and setters

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getWorkoutPlan() {
        return workoutPlan;
    }

    public void setWorkoutPlan(String workoutPlan) {
        this.workoutPlan = workoutPlan;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public int getEvents() {
        return events;
    }

    public void setEvents(int events) {
        this.events = events;
    }

}


