package com.paradigmas.hito;

public class CostCalculator {
    public static double calculateTotalCost(User user) {
        double totalCost = 0.0;
        double trainingCost = calculateTrainingCost(user.getWorkoutPlan());
        double competitionCost = calculateCompetitionCost(user.getWeight(), user.getEvents());

        totalCost = (trainingCost * 4) + competitionCost;

        return totalCost;
    }

    public static double calculateTrainingCost(String workoutPlan) {
        double trainingCost = 0.0;

        // calcula el costo de los entrenamientos según el plan de trabajo
        if (workoutPlan.equals("Basico")) {
            // calcula el costo de los entrenamientos básicos
            trainingCost = 20.0;  // Ejemplo: costo fijo de $22 para los entrenamientos básicos
        } else if (workoutPlan.equals("Intermedio")) {
            // calcula el costo de los entrenamientos intermedios
            int trainingHours = 4;  // Ejemplo: 4 horas de entrenamiento a la semana
            double hourlyRate = 6.25;  // Ejemplo: tarifa horaria de $6,25
            trainingCost = trainingHours * hourlyRate;
        } else if (workoutPlan.equals("Avanzado")) {
            // calcula el costo de los entrenamientos avanzados
            int trainingHours = 5;  // Ejemplo: 5 horas de entrenamiento a la semana
            double hourlyRate = 7.0;  // Ejemplo: tarifa horaria de $7
            trainingCost = trainingHours * hourlyRate;
        }

        return trainingCost;
    }

    public static double calculateCompetitionCost(double weight, int events) {
        double competitionCost = 0.0;

        // calcula el costo de las competiciones según la categoría de peso
        if (weight <= 60.0) {
            // calcula el costo para la categoría de peso menor o igual a 60 kg
            competitionCost = 25.0;  // Ejemplo: costo fijo de $30 para esa categoría
        } else if (weight >= 60.0 && weight < 75.0) {
            // calcula el costo para la categoría de peso entre 60 kg y 75 kg (inclusive)
            competitionCost = 35.0;  // Ejemplo: costo fijo de $40 para esa categoría
        } else if (weight >= 75.0 && weight < 90.0) {
            // calcula el costo para la categoría de peso entre 75 kg y 90 kg (inclusive)
            competitionCost = 42.0;  // Ejemplo: costo fijo de $50 para esa categoría
        } else if (weight >= 90.0 && weight < 105.0) {
            // calcula el costo para la categoría de peso entre 90 kg y 105 kg (inclusive)
            competitionCost = 50.0;  // Ejemplo: costo fijo de $60 para esa categoría
        } else {
            // calcula el costo para cualquier otra categoría de peso
        	competitionCost = 58.0;
        }
        
        // Multiplica el costo de la competición por el número de eventos
        competitionCost *= events;

        return competitionCost;
    }
}


