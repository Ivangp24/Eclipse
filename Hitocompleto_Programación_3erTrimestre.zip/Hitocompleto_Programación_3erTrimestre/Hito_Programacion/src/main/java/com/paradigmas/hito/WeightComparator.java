package com.paradigmas.hito;

public class WeightComparator {
    public static String compareWeight(User user) {
        String category = "";

        double weight = user.getWeight();

        if (weight <= 60.0) {
            category = "Peso Pluma";
        } else if (weight >= 60.0 && weight < 75.0) {
            category = "Peso Ligero";
        } else if (weight >= 75.0 && weight < 90.0) {
            category = "Peso Medio";
        } else if (weight >= 90.0 && weight < 105.0) {
            category = "Peso Pesado";
        } else {
            category = "Categoría no disponible";
        }

        return category;
    }
}


