package com.paradigmas.hito;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

//DATA Access Object : capa de gestión de datos : CRUD
public class ClienteDAO {
	
	private String endpoint="jdbc:mysql://localhost:3306/test?useSSL=false";
	private String user="root";
	private String pass="";
	
	public Connection conectar() {
        Connection connection =null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(endpoint, user, pass);
        } catch (ClassNotFoundException e) {

            e.printStackTrace();
        } catch (SQLException e) {

            e.printStackTrace();
        }//cierra método conectar
        
        return connection;
	}
	
	//insertar
	
	   public void insertUser(User c) {
		   

		   
	        	Connection connection = conectar(); 
	        	PreparedStatement ps;
				try {
					ps = connection.prepareStatement("INSERT INTO solocrossfit_hito (username, workoutPlan, weight, events) VALUES (?,?,?,?);");
		            ps.setString(1, c.getUsername());
		            ps.setString(2, c.getWorkoutPlan());
		            ps.setDouble(3, c.getWeight());
		            ps.setInt(4, c.getEvents());
		            ps.executeUpdate();
				} catch (SQLException e) {

					e.printStackTrace();
				} 

	    }//cierra insertar
	   
	   //resto de métodos CRUD



}//cierra DAO


