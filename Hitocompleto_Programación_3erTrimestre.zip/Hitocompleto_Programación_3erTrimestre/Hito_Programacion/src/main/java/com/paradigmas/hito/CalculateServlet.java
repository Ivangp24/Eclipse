package com.paradigmas.hito;

import javax.servlet.http.HttpServlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.paradigmas.hito.ClienteDAO;

@WebServlet("/calculate")
public class CalculateServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String workoutPlan = request.getParameter("workoutPlan");
        double weight = Double.parseDouble(request.getParameter("weight"));
        int events = Integer.parseInt(request.getParameter("events"));

        // realiza los cálculos y prepara los resultados
        User user = new User(username, workoutPlan, weight, events);
		ClienteDAO dao=new ClienteDAO();
		dao.insertUser(user);
        double totalCost = calculateTotalCost(user);
        String weightCategory = compareWeight(weight);

        // Guarda los resultados en atributos de la solicitud
        request.setAttribute("username", username);
        request.setAttribute("totalCost", totalCost);
        request.setAttribute("weightCategory", weightCategory);
        request.setAttribute("events", events);

        // Redirige al archivo JSP para mostrar los resultados
        request.getRequestDispatcher("result.jsp").forward(request, response);
    }
    

    private double calculateTotalCost(User user) {
        double totalCost = 0.0;

        //  calcula el costo total de entrenamientos y competiciones
        // llama a métodos de la clase CostCalculator
        totalCost = CostCalculator.calculateTotalCost(user);

        return totalCost;
    }

    private String compareWeight(double weight) {
        String weightCategory = "";

        // compara el peso actual con la categoría de peso en la competición
        // llama a métodos de la clase WeightComparator
        weightCategory = WeightComparator.compareWeight(new User("", "", weight, 0));

        return weightCategory;
    }
}



