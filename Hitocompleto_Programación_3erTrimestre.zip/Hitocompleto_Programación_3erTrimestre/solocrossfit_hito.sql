-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 12-05-2023 a las 12:02:07
-- Versión del servidor: 10.4.25-MariaDB
-- Versión de PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `test`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solocrossfit_hito`
--

CREATE TABLE `solocrossfit_hito` (
  `id` int(11) NOT NULL,
  `username` varchar(40) NOT NULL,
  `workoutPlan` varchar(20) NOT NULL,
  `weight` int(11) NOT NULL,
  `events` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `solocrossfit_hito`
--

INSERT INTO `solocrossfit_hito` (`id`, `username`, `workoutPlan`, `weight`, `events`) VALUES
(1, 'juan', 'basico', 72, 2),
(2, 'Julian', 'Basico', 45, 2),
(3, 'Lucia', 'Intermedio', 66, 0),
(4, 'Mariana', 'Intermedio', 60, 2),
(5, 'Paula', 'Intermedio', 53, 2),
(6, 'roberta', 'Intermedio', 65, 2),
(7, 'Alvaro', 'Intermedio', 86, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `solocrossfit_hito`
--
ALTER TABLE `solocrossfit_hito`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `solocrossfit_hito`
--
ALTER TABLE `solocrossfit_hito`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
